﻿using Lista.AutoMapperConfiguration;
using Lista.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Lista.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ListaController : ControllerBase
    {
        string lugar = @".\Data\ListaDoPapaiNoel.json";
       
        [HttpPost]
        public IActionResult RegistroDaLista([FromBody]ViewModel Lista)
        {
            Directory.CreateDirectory(caminho.Substring(0, caminho.LastIndexOf('\\')+1));
            string jsonRead = System.IO.File.ReadAllText(caminho);
            var PesquisaLista = JsonConvert.DeserializeObject<IEnumerable<Entities.Lista>>(jsonRead);
            List<Entities.Lista> lista = PesquisarLista.ToList();
            Entities.Lista newListaDoPapaiNoel = AutoMapperConfig.Map.Map<Entities.Lista>(lista);
            newMegaSena.atualizarData();
            lista.Add(newLista);
            string json = JsonConvert.SerializeObject(lista);
            System.IO.File.WriteAllText(caminho, json);
            return Ok();
        }

        [HttpGet]
        public IEnumerable<ListaPapaiNoelViewModel> ObterNomes()
        {
            string json = System.IO.File.ReadAllText(caminho);
            IEnumerable<Entities.ListaDoPapaiNoel> PesquisaLista = JsonConvert.DeserializeObject<IEnumerable<Entities.Lista>>(json);
            return AutoMapperConfig.Map.Map<IEnumerable<ListaViewModel>>(PesquisaLista);
        }

    }
}
