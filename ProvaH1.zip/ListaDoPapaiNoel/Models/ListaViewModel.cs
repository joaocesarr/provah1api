﻿using MegaSena.Atributos;
using System.ComponentModel.DataAnnotations;

namespace Lista.Models
{
    public class ListaViewModel
    {
        [CustomStringLengthValidation(5, 255)]
        public string NomeDaCrianca { get; set; }
        
        [CustomStringLengthValidation(5, 500)]
        public string TextoDaCriança { get; set; }
        
        [EndereçoValidation]
        public string Endereço{ get; set; }

        [Range(1, 3)]
        public int PrimeiroNome { get; set; }
        [Range(1, 3)]
        public int SegundoNome { get; set; }
        [Range(1, 3)]
        public int TerceiroNome { get; set; }
       
    }
}
