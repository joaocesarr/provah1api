﻿using Lista.Atributos;
using System.ComponentModel.DataAnnotations;

namespace Lista.Entities
{
    public class ListaDoPapaiNoel
    {
        public string NomeDaCrianca { get; set; }
        public string Endereco { get; set; }
        public int Idade { get; set; }
        public string TextoDaCartinha { get; set; }
        

       
       
    }
}
