﻿using AutoMapper;
using Lista.Entities;
using Lista.Models;

namespace Lista.AutoMapperConfiguration
{
    public class DomainToViewModelProfile : Profile
    {
        public DomainToViewModelProfile() 
        {
            CreateMap<Entities.Lista, ListaViewModel>();
        }
    }
}
