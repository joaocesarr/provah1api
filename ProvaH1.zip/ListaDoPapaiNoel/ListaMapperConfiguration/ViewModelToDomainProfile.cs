﻿using AutoMapper;
using Lista.Entities;
using Lista.Models;

namespace Lista.AutoMapperConfiguration
{
    public class ViewModelToDomainProfile : Profile
    {
        public ViewModelToDomainProfile() 
        {
            CreateMap<ListaViewModel, Entities.Lista>();
        }
    }
}
