﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Lista.Atributos
{
    public class CustomStringLengthValidationAttribute : ValidationAttribute
    {
        public string IdadeDaCriança { get; set; }
        private int idade<15;
        private int _minLength;

        public CustomStringLengthValidationAttribute (int Min , int Max)
        {
            
            _minLength = Min;
        }
        public override bool IsValid(object? value)
        {
            string Str = value as string;

            if (string.IsNullOrEmpty(Str)) return false;
            return Str.Length <= && Str.Length >= _minLength;
            
        }
    }
}
